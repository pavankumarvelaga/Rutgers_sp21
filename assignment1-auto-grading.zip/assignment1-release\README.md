# Auto Grader for Rutgers CS520 Spring 2021: Assignment 1

Required packages: Python 3.8.5 with (optionally) numpy 1.19.5 and matplotlib 3.3.3.

Replace `mp520.py` with your solution, Then run 
```
python main.py
```
