

'''
GCD algorithm
'''
def gcd(a, b):
    return (-1, 0, 0)

'''
Rectangles on a rubik's cube
'''
def rubiks(n):
    return -1


'''
Guessing a number
'''
def guess_unlimited(n, is_this_it):
    # The code here is only for illustrating how is_this_it() may be used 
    guess = n/2 
    if is_this_it(guess) == True:
        return guess
    return -1
        
'''
Guessing a number where you can only make two guesses that are larger
'''
def guess_limited(n, is_this_smaller):
    return -1
        

'''
Graph operations  
'''
def  add_vertex(graph):
    return graph

def  delete_vertex(graph, vid):
    return graph

def  add_edge(graph, vid1, vid2):
    return graph

def  delete_edge(graph, vid1, vid2):
    return graph

def  has_cycle(graph):
    return False

def  is_connected(graph):
    return False

